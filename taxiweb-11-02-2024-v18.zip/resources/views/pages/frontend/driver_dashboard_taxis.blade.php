@extends('layouts.frontend_dashboard')

@section('content')

<div class="user-profile-wrapper">
    <div class="row">
       <div class="col-lg-12">
          <div class="user-profile-card">
             <h4 class="user-profile-card-title">Taxis</h4>
             <button type="button" class="btn btn-warning float-right mb-3" data-bs-toggle="modal" data-bs-target="#addTaxiModal">Add Taxi</button>
             <div class="table-responsive w-100" id="taxis">

             </div>
          </div>
       </div>
    </div>
 </div>


@endsection

@push('css')
<style>

</style>
@endpush
@push('scripts')
<script>

$(document).ready(function() {

    $(document).on('click','.activeTaxis',function(){
        var taxiDatas = $(this).attr('data-id');
        var taxiDataArry = taxiDatas.split('/');
        var checkUserUrl = '{{ route("driver.activetaxi") }}';
        var csrfToken = '{{ csrf_token() }}';

        //console.log(taxiDatas);
        $.ajax({
            url: checkUserUrl,
            type: 'GET',
            //dataType: 'json',
            data: { action: 'checkuser',taxi_id:taxiDataArry[0],user_id:taxiDataArry[1],taxi_status:taxiDataArry[2], _token: csrfToken },
            success: function(response) {
                fetchTaxis();
                Swal.fire({
                    position: "bottom-end",
                    icon: response.messageType === 'success' ? "success" : "error",
                    title: response.message,
                    showConfirmButton: false,
                    timer: response.messageType === 'success' ? 4000 : 2500
                });
            }
        });
    });

    fetchTaxis();
    function fetchTaxis(){
        var checkUserUrl = '{{ route("driver.fetchtaxis") }}';
        var csrfToken = '{{ csrf_token() }}';

        $.ajax({
            url: checkUserUrl,
            type: 'GET',
            //dataType: 'json',
            data: { action: 'checkuser', _token: csrfToken },
            success: function(data) {
                //console.log(data);
                //if (data.pending_booking) {
                    $('#taxis').html(data);
                //}
                    // Destroy any existing DataTable instances on this element
                    if ($.fn.DataTable.isDataTable('.table')) {
                        $('.table').DataTable().destroy();
                    }
                    // Initialize DataTable after inserting the data
                    $('.table').DataTable({
                        lengthChange: false,
                        info: false,
                        ordering: false,
                        paging: true
                    });
            }
        });
    }


});
</script>

@endpush
