<?php $__env->startSection('content'); ?>

             <div class="user-profile-wrapper">
                <div class="row">
                   <div class="col-md-6 col-lg-4">
                      <div class="dashboard-widget dashboard-widget-color-1">
                         <div class="dashboard-widget-info">
                            <h1><?php echo e($allUpcommingBooking ?? 0); ?></h1>
                            <span>Pending Booking</span>
                         </div>
                         <div class="dashboard-widget-icon">
                            <i class="fal fa-list"></i>
                         </div>
                      </div>
                   </div>
                   <div class="col-md-6 col-lg-4">
                      <div class="dashboard-widget dashboard-widget-color-2">
                         <div class="dashboard-widget-info">
                            <h1><?php echo e($allTotalBooking ?? 0); ?></h1>
                            <span>Total Booking</span>
                         </div>
                         <div class="dashboard-widget-icon">
                            <i class="fal fa-eye"></i>
                         </div>
                      </div>
                   </div>
                   <div class="col-md-6 col-lg-4">
                      <div class="dashboard-widget dashboard-widget-color-3">
                         <div class="dashboard-widget-info">
                            <h1><?php echo e($allCancelBooking ?? 0); ?></h1>
                            <span>Cancel Booking</span>
                         </div>
                         <div class="dashboard-widget-icon">
                            <i class="fal fa-xmark-circle"></i>
                         </div>
                      </div>
                   </div>
                </div>
                <div class="row">
                   <div class="col-lg-12">
                      <div class="user-profile-card">
                         <h4 class="user-profile-card-title">Pending Booking</h4>
                         <div class="table-responsive" id="pendingBooking">

                         </div>
                      </div>
                   </div>
                </div>
             </div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>

</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    fetchPendingBooking();
    function fetchPendingBooking(){
        var checkUserUrl = '<?php echo e(route("driver.fetchdriverpendingbooking")); ?>';
        var csrfToken = '<?php echo e(csrf_token()); ?>';

        $.ajax({
            url: checkUserUrl,
            type: 'GET',
            //dataType: 'json',
            data: { action: 'checkuser', _token: csrfToken },
            success: function(data) {
                //console.log(data);
                //if (data.pending_booking) {
                    $('#pendingBooking').html(data);
                //}
            },
            error: function(xhr, status, error) {
                console.error('Error:', error,status,xhr);
            }
        });
    }
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\taxiweb\resources\views/pages/frontend/driver_dashboard.blade.php ENDPATH**/ ?>