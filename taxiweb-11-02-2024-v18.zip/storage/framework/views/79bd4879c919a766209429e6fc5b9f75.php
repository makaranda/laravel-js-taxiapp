<?php $__env->startSection('content'); ?>

<div class="user-profile-wrapper">
    <div class="row">
       <div class="col-lg-12">
          <div class="user-profile-card">
             <h4 class="user-profile-card-title">Taxis</h4>
             <button type="button" class="btn btn-warning float-right mb-3" data-bs-toggle="modal" data-bs-target="#addTaxiModal">Add Taxi</button>
             <div class="table-responsive w-100" id="taxis">

             </div>
          </div>
       </div>
    </div>
 </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>

</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script>

$(document).ready(function() {

    $(document).on('click','.activeTaxis',function(){
        var taxiDatas = $(this).attr('data-id');
        var taxiDataArry = taxiDatas.split('/');
        var checkUserUrl = '<?php echo e(route("driver.activetaxi")); ?>';
        var csrfToken = '<?php echo e(csrf_token()); ?>';

        //console.log(taxiDatas);
        $.ajax({
            url: checkUserUrl,
            type: 'GET',
            //dataType: 'json',
            data: { action: 'checkuser',taxi_id:taxiDataArry[0],user_id:taxiDataArry[1],taxi_status:taxiDataArry[2], _token: csrfToken },
            success: function(response) {
                fetchTaxis();
                Swal.fire({
                    position: "bottom-end",
                    icon: response.messageType === 'success' ? "success" : "error",
                    title: response.message,
                    showConfirmButton: false,
                    timer: response.messageType === 'success' ? 4000 : 2500
                });
            }
        });
    });

    fetchTaxis();
    function fetchTaxis(){
        var checkUserUrl = '<?php echo e(route("driver.fetchtaxis")); ?>';
        var csrfToken = '<?php echo e(csrf_token()); ?>';

        $.ajax({
            url: checkUserUrl,
            type: 'GET',
            //dataType: 'json',
            data: { action: 'checkuser', _token: csrfToken },
            success: function(data) {
                //console.log(data);
                //if (data.pending_booking) {
                    $('#taxis').html(data);
                //}
                    // Destroy any existing DataTable instances on this element
                    if ($.fn.DataTable.isDataTable('.table')) {
                        $('.table').DataTable().destroy();
                    }
                    // Initialize DataTable after inserting the data
                    $('.table').DataTable({
                        lengthChange: false,
                        info: false,
                        ordering: false,
                        paging: true
                    });
            }
        });
    }


});
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\taxiweb\resources\views/pages/frontend/driver_dashboard_taxis.blade.php ENDPATH**/ ?>