<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="noindex,nofollow">
    <title>Taxi App | Admin Dashbord</title>
        <?php echo $__env->make('libraries.app.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('css'); ?>
    </head>
  <body>
        <?php echo $__env->make('components.app.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="overlay" style="display: block;">
            <div class="loader"></div>
        </div>
        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('components.app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('libraries.app.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>
  </body>
</html>
<?php /**PATH D:\xampp\htdocs\taxiweb\resources\views/layouts/app.blade.php ENDPATH**/ ?>