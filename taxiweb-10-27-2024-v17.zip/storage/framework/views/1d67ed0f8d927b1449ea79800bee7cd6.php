

<script src="<?php echo e(url('public/assets/login/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/login/vendor/animsition/js/animsition.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/login/vendor/bootstrap/js/popper.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/login/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/login/vendor/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/login/vendor/daterangepicker/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/login/vendor/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/login/vendor/countdowntime/countdowntime.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/login/js/main.js')); ?>"></script>

<script src="<?php echo e(url('public/assets/js/paginathing.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/jquery.redirect.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/parsley.js')); ?>"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php /**PATH D:\xampp\htdocs\taxiweb\resources\views/libraries/login/scripts.blade.php ENDPATH**/ ?>