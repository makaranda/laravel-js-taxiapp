<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="noindex,nofollow">
    <title>Taxi App | Esoft ASE Assignment</title>
        <?php echo $__env->make('libraries.frontend.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('css'); ?>
    </head>
  <body>
    <?php echo $__env->make('components.frontend.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="overlay" style="display: block;">
        <div class="loader"></div>
    </div>
    <?php
    if (Auth::check()) {
        if(Auth::user()->role == 'customer'){
            $personTitle = 'Customer';
            $userLoginType = 'customer';
            $homeRoute = route('customer.dashboard');
        }else if(Auth::user()->role == 'driver'){
            $personTitle = 'Driver';
            $userLoginType = 'driver';
            $homeRoute = route('driver.dashboard');
        }else{
            $personTitle = '';
            $homeRoute = '';
            $userLoginType = '';
        }
    }else{
        $personTitle = '';
        $homeRoute = '';
        $userLoginType = '';
    }
    ?>
    <input type="hidden" name="user_login_type" id="user_login_type" value="<?php echo e($userLoginType); ?>">
    <div class="site-breadcrumb" style="background: url(<?php echo e(url('public/assets/img/breadcrumb/01.jpg')); ?>)">
        <div class="container">
           <h2 class="breadcrumb-title"><?php echo e($personTitle); ?> Dashboard</h2>
           <ul class="breadcrumb-menu">
              <li><a href="<?php echo e($homeRoute); ?>">Home</a></li>
              <li class="active"><?php echo e($personTitle); ?> Dashboard</li>
           </ul>
        </div>
     </div>
     <div class="user-profile py-120">
        <div class="container">
           <div class="row">
              <div class="col-lg-3">
                <?php echo $__env->make('components.frontend.user_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
              <div class="col-lg-9">
                <?php echo $__env->yieldContent('content'); ?>
              </div>
            </div>
        </div>
     </div>
        <?php echo $__env->make('components.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('libraries.frontend.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>
  </body>
</html>
<?php /**PATH D:\xampp\htdocs\taxiweb\resources\views/layouts/frontend_dashboard.blade.php ENDPATH**/ ?>