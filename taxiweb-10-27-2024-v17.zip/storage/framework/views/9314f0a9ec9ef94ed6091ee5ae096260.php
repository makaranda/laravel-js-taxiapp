<link rel="icon" type="image/x-icon" href="<?php echo e(url('public/assets/img/logo/favicon.png')); ?>">

<link rel="stylesheet" href="<?php echo e(url('public/assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/all-fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/animate.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/magnific-popup.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/jquery.timepicker.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/nice-select.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/style.css')); ?>">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
<!-- Leaflet CSS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<!-- Leaflet JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>


<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

<link rel="stylesheet" href="<?php echo e(url('public/assets/css/parsley.css')); ?>?v=<?php echo e(date('is')); ?>"/>
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/padding.css')); ?>?v=<?php echo e(date('is')); ?>"/>

<link rel="stylesheet" href="<?php echo e(url('public/assets/css/mystyle.css')); ?>?v=<?php echo e(date('is')); ?>"/>
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/mystyle.responsive.css')); ?>?v=<?php echo e(date('is')); ?>"/>



<script src="<?php echo e(url('public/assets/js/polyline.js')); ?>"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<?php /**PATH D:\xampp\htdocs\taxiweb\resources\views/libraries/frontend/styles.blade.php ENDPATH**/ ?>